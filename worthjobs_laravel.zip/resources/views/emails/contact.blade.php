<h1>Feedback</h1>
<p>
    Name:{{ $name }}<br>
    Email: {{ $email }} <br>
    Phone: {{$phone}}
</p>
<h5>
    Message:
</h5>
<p>
    {{ $user_message }}
</p>